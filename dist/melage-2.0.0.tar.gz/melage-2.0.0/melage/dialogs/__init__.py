from .AboutDialog import about_dialog
from .ActivationDialog import activation_dialog
from .HistogramDialog import HistImage, FigureCanvas
from .ImInfoDialog import iminfo_dialog
from .MaskingDialog import Masking
from .MaskOperationsDialog import MaskOperationsDialog
from .RegistrationDialog import RegistrationDialog
from .ThresholdingDialog import ThresholdingImage
from .TransformationDialog import TransformationDialog