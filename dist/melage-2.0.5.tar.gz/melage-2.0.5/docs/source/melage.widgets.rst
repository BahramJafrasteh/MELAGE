melage.widgets package
======================

Submodules
----------

melage.widgets.DockWidgets module
---------------------------------

.. automodule:: melage.widgets.DockWidgets
   :members:
   :undoc-members:
   :show-inheritance:

melage.widgets.EnhanceImageWidget module
----------------------------------------

.. automodule:: melage.widgets.EnhanceImageWidget
   :members:
   :undoc-members:
   :show-inheritance:

melage.widgets.SettingsWidget module
------------------------------------

.. automodule:: melage.widgets.SettingsWidget
   :members:
   :undoc-members:
   :show-inheritance:

melage.widgets.SideBar module
-----------------------------

.. automodule:: melage.widgets.SideBar
   :members:
   :undoc-members:
   :show-inheritance:

melage.widgets.openglWidgets module
-----------------------------------

.. automodule:: melage.widgets.openglWidgets
   :members:
   :undoc-members:
   :show-inheritance:

melage.widgets.plugin\_manager module
-------------------------------------

.. automodule:: melage.widgets.plugin_manager
   :members:
   :undoc-members:
   :show-inheritance:

melage.widgets.toggle module
----------------------------

.. automodule:: melage.widgets.toggle
   :members:
   :undoc-members:
   :show-inheritance:

melage.widgets.ui\_builder module
---------------------------------

.. automodule:: melage.widgets.ui_builder
   :members:
   :undoc-members:
   :show-inheritance:

melage.widgets.ui\_schema module
--------------------------------

.. automodule:: melage.widgets.ui_schema
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: melage.widgets
   :members:
   :undoc-members:
   :show-inheritance:
