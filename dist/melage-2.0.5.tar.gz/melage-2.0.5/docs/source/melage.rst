melage package
==============

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   melage.config
   melage.dialogs
   melage.plugins
   melage.rendering
   melage.utils
   melage.widgets

Submodules
----------

melage.main module
------------------

.. automodule:: melage.main
   :members:
   :undoc-members:
   :show-inheritance:

melage.mainwindow\_widget module
--------------------------------

.. automodule:: melage.mainwindow_widget
   :members:
   :undoc-members:
   :show-inheritance:

melage.melage module
--------------------

.. automodule:: melage.melage
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: melage
   :members:
   :undoc-members:
   :show-inheritance:
