melage.plugins.warpseg package
==============================

Submodules
----------

melage.plugins.warpseg.WarpSeg module
-------------------------------------

.. automodule:: melage.plugins.warpseg.WarpSeg
   :members:
   :undoc-members:
   :show-inheritance:

melage.plugins.warpseg.WarpSeg\_schema module
---------------------------------------------

.. automodule:: melage.plugins.warpseg.WarpSeg_schema
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: melage.plugins.warpseg
   :members:
   :undoc-members:
   :show-inheritance:
