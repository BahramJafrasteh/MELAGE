melage.dialogs package
======================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   melage.dialogs.helpers

Submodules
----------

melage.dialogs.AboutDialog module
---------------------------------

.. automodule:: melage.dialogs.AboutDialog
   :members:
   :undoc-members:
   :show-inheritance:

melage.dialogs.HistogramDialog module
-------------------------------------

.. automodule:: melage.dialogs.HistogramDialog
   :members:
   :undoc-members:
   :show-inheritance:

melage.dialogs.ImInfoDialog module
----------------------------------

.. automodule:: melage.dialogs.ImInfoDialog
   :members:
   :undoc-members:
   :show-inheritance:

melage.dialogs.MaskOperationsDialog module
------------------------------------------

.. automodule:: melage.dialogs.MaskOperationsDialog
   :members:
   :undoc-members:
   :show-inheritance:

melage.dialogs.MaskingDialog module
-----------------------------------

.. automodule:: melage.dialogs.MaskingDialog
   :members:
   :undoc-members:
   :show-inheritance:

melage.dialogs.RegistrationDialog module
----------------------------------------

.. automodule:: melage.dialogs.RegistrationDialog
   :members:
   :undoc-members:
   :show-inheritance:

melage.dialogs.ThresholdingDialog module
----------------------------------------

.. automodule:: melage.dialogs.ThresholdingDialog
   :members:
   :undoc-members:
   :show-inheritance:

melage.dialogs.TransformationDialog module
------------------------------------------

.. automodule:: melage.dialogs.TransformationDialog
   :members:
   :undoc-members:
   :show-inheritance:

melage.dialogs.dynamic\_gui module
----------------------------------

.. automodule:: melage.dialogs.dynamic_gui
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: melage.dialogs
   :members:
   :undoc-members:
   :show-inheritance:
